package com.springProject.karolRebiger.courseapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
